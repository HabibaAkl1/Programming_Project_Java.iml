



import de.thd.dwd_data_retriever.IDwdDataRetriever;
import de.thd.dwd_data_retriever.datatypes.StationData;
import de.thd.dwd_data_retriever.datatypes.StationMetaData;
import de.thd.dwd_data_retriever.datatypes.StationNotFoundException;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;



public class DataAnalyzer {
    private IDwdDataRetriever dataRetriever;/* dataRetriever implementiert IDwdDataRetriever*/

    public DataAnalyzer(IDwdDataRetriever dataRetriever)/*Constructor*/ {
        this.dataRetriever = dataRetriever;
    }

    public String getStationName(int stationId) { /* StationMetaData klasse verwendet um methode getStationName zu verwenden*/

        try {
            StationMetaData metadata_Station = dataRetriever.getStationMetaData(stationId);
            return metadata_Station.getStationName();
        } catch (StationNotFoundException e) {
            return "Station Name Nicht gefunden";
        }
    }

    /*getters*/
    /*HochstrNiederschlag*/
    public String getNamemaxNiederschlag() {
        float maxNiederschlag = 0;
        String station_Name = "";
        List<Integer> stationIDs = dataRetriever.getStationIDs();

        for (Integer stationId : stationIDs) {
            try {
                StationData data = dataRetriever.getStationData(stationId);
                for (Float value : data.getRsk()) {   /*RSK = tägliche Niederschlagshöhe*/
                    if (value != null && value > maxNiederschlag) { /*Prüft, ob der aktuelle Niederschlagswert größer ist. Wenn ja, dann wird dieser Wert zurückgegeben
                     */
                        maxNiederschlag = value;
                        station_Name = getStationName(stationId);
                    }
                }
            } catch (StationNotFoundException e) {
                System.out.println("Station" + stationId + " nicht gefunden");
            }
        }
        return station_Name;
    }

    /*Hochster Schnee Wert*/
    public String getNameMaxSchnee() {
        float maxSchnee = 0;
        String station_Name = "";
        List<Integer> stationIDs = dataRetriever.getStationIDs();
        for (Integer stationId : stationIDs) {
            try {
                StationData data = dataRetriever.getStationData(stationId);
                for (Float value : data.getShkTag()) { /*SHK:Tageswert Schneehöhe*/
                    if (value != null && value > maxSchnee) {
                        maxSchnee = value;
                        station_Name = getStationName(stationId);
                    }
                }
            } catch (StationNotFoundException e) {
                System.out.println("Station " + stationId + "  nicht gefunden ");
            }
        }
        return station_Name;
    }


    /* Hochster Temperatur*/
    public String getNameMaxTemperatur() {
        float maxTemperatur = 0;
        String station_Name = "";
        for (Integer stationId : dataRetriever.getStationIDs()) {
            try {
                StationData data = dataRetriever.getStationData(stationId);
                for (Float value : data.getTxk()) {
                    if (value != null && value > maxTemperatur) {
                        maxTemperatur = value;
                        station_Name = getStationName(stationId);
                    }
                }
            } catch (StationNotFoundException e) {
                System.out.println("Station " + stationId + "  nicht gefunden ");
            }
        }
        return station_Name;
    }

    /*Niedrigest Temperatur*/

    public String getNameMinTemperatur() {
        float minTemperatur = 0;
        String station_Name = "";
        for (Integer stationId : dataRetriever.getStationIDs()) {
            try {
                StationData data = dataRetriever.getStationData(stationId);
                for (Float value : data.getTnk()) {/*Tagesminimum der Lufttemperatur*/
                    if (value != null && value < minTemperatur) { /*prüft, ob der aktuelle Wert niedriger ist, dann wird dieser Wert zurückgegeben*/
                        minTemperatur = value;
                        station_Name = getStationName(stationId);
                    }
                }
            } catch (StationNotFoundException e) {
                System.out.println("Station " + stationId + " nicht gefunden");
            }
        }
        return station_Name;
    }

    /*Hochster Wind Im mittel*/
    public String getNameMaxWind() {
        float maxWind = 0;
        String station_Name = "";
        for (Integer stationId : dataRetriever.getStationIDs()) {
            try {
                StationData data = dataRetriever.getStationData(stationId);
                for (Float value : data.getFm()) {/*Tagesmittel Windgeschwindigkeit*/
                    if (value != null && value > maxWind) {
                        maxWind = value;
                        station_Name = getStationName(stationId);
                    }
                }
            } catch (StationNotFoundException e) {
                System.out.println("Station" + stationId + "nicht gefunden");
            }
        }
        return station_Name;
    }

    /*
        /*Alteste*/
    public String getStation(ArrayList<StationData> stationMetaDataList) {
        int oldestStationId = -1; // Initialize to -1 to indicate no station has been found yet
        Date oldestDate = new Date(Long.MAX_VALUE); // Initialize to a very recent date
        String oldestStationName = "";

        List<Integer> stationIDs = dataRetriever.getStationIDs();
        for (Integer stationId : stationIDs) {
            try {
                StationData data = dataRetriever.getStationData(stationId);
                List<Date> measuringDates = data.getMeasuringDate();
                for (Date date : measuringDates) {
                    if (date.compareTo(oldestDate) < 0) {
                        oldestDate = date;
                        oldestStationId = stationId;
                    }
                }
            } catch (StationNotFoundException e) {
                System.out.println("Station " + stationId + " not found");
            }
        }


        return oldestStationName;
    }
}


